package com.example.gramaurja

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.flow.collectLatest

// ── COLORS ────────────────────────────────────────────────────────
val PrimaryGreen     = Color(0xFF1B5E20)
val LightGreen       = Color(0xFF43A047)
val OnPrimary        = Color(0xFFFFFFFF)
val PrimaryContainer = Color(0xFFC8E6C9)
val AppSurface       = Color(0xFFF1F8F1)
val ErrorRed         = Color(0xFFB71C1C)
val SurfaceVariant   = Color(0xFFDCEDC8)

// ── CROPS ─────────────────────────────────────────────────────────
data class Crop(val id: String, val name: String, val waterNeeds: String, val multiplier: Float)

val AllCrops = listOf(
    Crop("rice",      "Rice (Paddy)",  "High",   1.5f),
    Crop("wheat",     "Wheat",         "Medium", 0.8f),
    Crop("maize",     "Maize",         "Medium", 1.0f),
    Crop("cotton",    "Cotton",        "Low",    0.6f),
    Crop("sugarcane", "Sugarcane",     "High",   2.0f),
    Crop("groundnut", "Groundnut",     "Medium", 0.9f),
    Crop("soybean",   "Soybean",       "Medium", 1.1f),
    Crop("sunflower", "Sunflower",     "Low",    0.7f),
    Crop("tomato",    "Tomato",        "High",   1.3f),
    Crop("onion",     "Onion",         "Medium", 1.0f),
    Crop("potato",    "Potato",        "Medium", 1.2f),
    Crop("chilli",    "Chilli",        "Low",    0.8f)
)

// ── ROOT ──────────────────────────────────────────────────────────
@Composable
fun GramaUrjaRoot() {
    val authViewModel:  AuthViewModel  = viewModel()
    val powerViewModel: PowerViewModel = viewModel()
    var isLoggedIn by remember { mutableStateOf(authViewModel.isLoggedIn()) }

    if (isLoggedIn) {
        LaunchedEffect(Unit) { powerViewModel.startListening() }
        GramaUrjaApp(
            powerViewModel = powerViewModel,
            onLogout = {
                authViewModel.logout()
                powerViewModel.stopListening()
                isLoggedIn = false
            }
        )
    } else {
        AuthScreen(viewModel = authViewModel, onAuthSuccess = { isLoggedIn = true })
    }
}

// ── MAIN SHELL ────────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GramaUrjaApp(powerViewModel: PowerViewModel, onLogout: () -> Unit) {
    var activeTab    by remember { mutableStateOf("home") }
    val zones        by powerViewModel.zones.collectAsState()
    val selectedZone by powerViewModel.selectedZone.collectAsState()
    val isOnline     by powerViewModel.isOnline.collectAsState()
    val isSynced     by powerViewModel.isSynced.collectAsState()
    val userVillage  by powerViewModel.userVillage.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    // ✅ Snackbar listener
    LaunchedEffect(Unit) {
        powerViewModel.snackbarMsg.collectLatest { msg ->
            snackbarHostState.showSnackbar(msg, duration = SnackbarDuration.Short)
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // ✅ No internet banner
        if (!isOnline) {
            Box(
                modifier = Modifier.fillMaxWidth().background(ErrorRed).padding(vertical = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.WifiOff, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("No internet connection — showing cached data", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }

        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Grama-Urja", fontWeight = FontWeight.ExtraBold, color = PrimaryGreen, fontSize = 22.sp)
                            Spacer(Modifier.width(8.dp))
                            // ✅ LIVE badge
                            if (isSynced) {
                                Surface(
                                    color = Color(0xFF2E7D32),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Row(
                                        modifier          = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(modifier = Modifier.size(6.dp).background(Color(0xFF69F0AE), CircleShape))
                                        Spacer(Modifier.width(4.dp))
                                        Text("LIVE", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    },
                    navigationIcon = {
                        if (activeTab != "home") {
                            IconButton(onClick = { activeTab = "home" }) {
                                Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                            }
                        }
                    },
                    actions = {
                        IconButton(onClick = onLogout) {
                            Icon(Icons.Default.Logout, contentDescription = "Logout", tint = PrimaryGreen)
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = Color.White)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf(
                        Triple("home",   Icons.Default.Home,          "Home"),
                        Triple("zones",  Icons.Default.LocationOn,    "Zones"),
                        Triple("timer",  Icons.Default.Agriculture,   "Pump"),
                        Triple("alerts", Icons.Default.Notifications, "Alerts")
                    ).forEach { (id, icon, label) ->
                        NavigationBarItem(
                            selected = activeTab == id,
                            onClick  = { activeTab = id },
                            icon     = { Icon(icon, contentDescription = label) },
                            label    = { Text(label, fontSize = 12.sp) },
                            colors   = NavigationBarItemDefaults.colors(
                                selectedIconColor = PrimaryGreen,
                                selectedTextColor = PrimaryGreen,
                                indicatorColor    = PrimaryContainer
                            )
                        )
                    }
                }
            }
        ) { padding ->
            Box(modifier = Modifier.padding(padding).fillMaxSize().background(AppSurface)) {
                when (activeTab) {
                    "home"   -> HomeScreen(
                        zone           = selectedZone,
                        userVillage    = userVillage,
                        onStatusChange = { on ->
                            selectedZone?.let { powerViewModel.updatePowerStatus(it.zoneId, on) }
                        },
                        onChangeZone   = { activeTab = "zones" }
                    )
                    "zones"  -> ZoneListScreen(
                        zones       = zones,
                        userVillage = userVillage,
                        isLoading   = powerViewModel.isLoading.collectAsState().value,
                        onSelect    = { powerViewModel.selectZone(it); activeTab = "home" },
                        onAddZone   = { name, village, onErr -> powerViewModel.addZone(name, village, onErr) }
                    )
                    "timer"  -> PumpTimerScreen()
                    "alerts" -> AlertsScreen(powerViewModel)
                }
            }
        }
    }
}

// ── HOME SCREEN ───────────────────────────────────────────────────
@Composable
fun HomeScreen(
    zone: ZoneStatus?,
    userVillage: String,
    onStatusChange: (Boolean) -> Unit,
    onChangeZone: () -> Unit
) {
    if (zone == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator(color = PrimaryGreen, modifier = Modifier.size(52.dp), strokeWidth = 4.dp)
                Spacer(Modifier.height(16.dp))
                Text("Connecting to your village network...", color = Color.Gray, fontSize = 15.sp)
                if (userVillage.isNotBlank()) {
                    Text(userVillage, color = PrimaryGreen, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
        }
        return
    }

    Column(
        modifier            = Modifier.fillMaxSize().padding(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // ✅ "Showing updates for: Village" label
        if (userVillage.isNotBlank()) {
            Surface(
                color  = PrimaryContainer,
                shape  = RoundedCornerShape(20.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier          = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Place, contentDescription = null, tint = PrimaryGreen, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        "Showing updates for: ",
                        color    = PrimaryGreen,
                        fontSize = 13.sp
                    )
                    Text(
                        userVillage,
                        color      = PrimaryGreen,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize   = 13.sp
                    )
                }
            }

            Spacer(Modifier.height(12.dp))
        }

        // ── Zone selector card ────────────────────────────────────
        Card(
            modifier  = Modifier.fillMaxWidth().clickable { onChangeZone() },
            shape     = RoundedCornerShape(18.dp),
            colors    = CardDefaults.cardColors(containerColor = Color.White),
            border    = BorderStroke(1.dp, SurfaceVariant),
            elevation = CardDefaults.cardElevation(2.dp)
        ) {
            Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.ElectricBolt, contentDescription = null, tint = PrimaryGreen, modifier = Modifier.size(26.dp))
                Spacer(Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        zone.zoneName.ifBlank { "Select a Zone" },
                        fontWeight = FontWeight.ExtraBold,
                        fontSize   = 17.sp,
                        color      = if (zone.zoneName.isBlank()) Color.Gray else Color.Black
                    )
                    Text(zone.village.ifBlank { "Tap to select zone" }, color = Color.Gray, fontSize = 13.sp)
                }
                Surface(color = AppSurface, shape = RoundedCornerShape(10.dp)) {
                    Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Change", color = PrimaryGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = PrimaryGreen, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))

        // ── Status card ───────────────────────────────────────────
        Card(
            modifier = Modifier.fillMaxWidth().height(250.dp),
            colors   = CardDefaults.cardColors(
                containerColor = if (zone.isPowerOn) Color(0xFFE8F5E9) else Color(0xFFFFEBEE)
            ),
            shape = RoundedCornerShape(30.dp)
        ) {
            Column(
                modifier            = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Glowing status circle
                Box(
                    modifier = Modifier
                        .size(90.dp)
                        .background(
                            if (zone.isPowerOn) Color(0x332E7D32) else Color(0x33B71C1C),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(66.dp)
                            .background(
                                if (zone.isPowerOn) Color(0xFF2E7D32) else Color(0xFFB71C1C),
                                CircleShape
                            )
                    )
                }

                Spacer(Modifier.height(14.dp))

                Text(
                    text       = if (zone.isPowerOn) "⚡  POWER IS ON" else "🔴  POWER IS OFF",
                    style      = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold,
                    color      = if (zone.isPowerOn) Color(0xFF1B5E20) else Color(0xFFB71C1C)
                )

                Spacer(Modifier.height(6.dp))

                // ✅ "X mins ago" freshness
                Text(zone.lastUpdated, color = Color.Gray, fontSize = 14.sp)
                Text(
                    "by ${zone.updatedBy.substringBefore("@").ifBlank { "Community update" }}",
                    color    = Color.Gray,
                    fontSize = 12.sp
                )
            }
        }

        Spacer(Modifier.height(20.dp))

        Text(
            "Help your community — report what you see:",
            fontWeight = FontWeight.SemiBold,
            color      = Color(0xFF4E4E4E),
            fontSize   = 13.sp,
            textAlign  = TextAlign.Center
        )

        Spacer(Modifier.height(10.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Button(
                onClick  = { onStatusChange(true) },
                modifier = Modifier.weight(1f).height(64.dp),
                shape    = RoundedCornerShape(18.dp),
                colors   = ButtonDefaults.buttonColors(
                    containerColor = if (zone.isPowerOn) PrimaryGreen else Color(0xFFBDBDBD),
                    contentColor   = Color.White
                )
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("⚡", fontSize = 18.sp)
                    Text("MARK ON", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                }
            }
            Button(
                onClick  = { onStatusChange(false) },
                modifier = Modifier.weight(1f).height(64.dp),
                shape    = RoundedCornerShape(18.dp),
                colors   = ButtonDefaults.buttonColors(
                    containerColor = if (!zone.isPowerOn) ErrorRed else Color(0xFFBDBDBD),
                    contentColor   = Color.White
                )
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🔴", fontSize = 18.sp)
                    Text("MARK OFF", fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        // Community tip
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape    = RoundedCornerShape(14.dp),
            colors   = CardDefaults.cardColors(containerColor = Color(0xFFFFF9C4))
        ) {
            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("💡", fontSize = 20.sp)
                Spacer(Modifier.width(10.dp))
                Text(
                    "If power is ON at ${zone.zoneName}, tap MARK ON — all farmers in ${zone.village} get notified instantly!",
                    fontSize = 12.sp,
                    color    = Color(0xFF5D4037)
                )
            }
        }
    }
}

// ── ZONE LIST ─────────────────────────────────────────────────────
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ZoneListScreen(
    zones: List<ZoneStatus>,
    userVillage: String,
    isLoading: Boolean,
    onSelect: (ZoneStatus) -> Unit,
    onAddZone: (String, String, (String) -> Unit) -> Unit
) {
    var searchQuery   by remember { mutableStateOf("") }
    var showAddDialog by remember { mutableStateOf(false) }
    var dialogError   by remember { mutableStateOf("") }

    val filtered = zones.filter {
        it.zoneName.contains(searchQuery, ignoreCase = true) ||
        it.village.contains(searchQuery, ignoreCase = true)
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)) {
            // ✅ Village label
            if (userVillage.isNotBlank()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.FilterList, contentDescription = null, tint = PrimaryGreen, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Zones in: ", color = Color.Gray, fontSize = 13.sp)
                    Text(userVillage, color = PrimaryGreen, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                }
                Spacer(Modifier.height(10.dp))
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                TextField(
                    value         = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier      = Modifier.weight(1f),
                    placeholder   = { Text("Search zone name...") },
                    leadingIcon   = { Icon(Icons.Default.Search, contentDescription = null) },
                    singleLine    = true,
                    shape         = RoundedCornerShape(24.dp),
                    colors        = TextFieldDefaults.colors(
                        focusedIndicatorColor   = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent,
                        focusedContainerColor   = Color.White,
                        unfocusedContainerColor = Color.White
                    )
                )
                Spacer(Modifier.width(10.dp))
                FloatingActionButton(
                    onClick        = { dialogError = ""; showAddDialog = true },
                    containerColor = PrimaryGreen,
                    contentColor   = Color.White,
                    modifier       = Modifier.size(52.dp)
                ) { Icon(Icons.Default.Add, contentDescription = "Add Zone") }
            }

            Spacer(Modifier.height(6.dp))
            Text("${filtered.size} zone${if (filtered.size != 1) "s" else ""}", color = Color.Gray, fontSize = 12.sp)
        }

        when {
            isLoading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = PrimaryGreen)
            }
            zones.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🏘️", fontSize = 48.sp)
                    Spacer(Modifier.height(12.dp))
                    Text("No zones in $userVillage yet", color = Color.Gray, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("Tap + to add your local transformer zone", color = Color.Gray, fontSize = 13.sp, textAlign = TextAlign.Center)
                }
            }
            filtered.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No results for \"$searchQuery\"", color = Color.Gray, fontSize = 15.sp)
            }
            else -> LazyColumn(
                modifier            = Modifier.fillMaxSize(),
                contentPadding      = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filtered, key = { it.zoneId }) { zone ->
                    ZoneCard(zone = zone, onClick = { onSelect(zone) })
                }
            }
        }
    }

    if (showAddDialog) {
        AddZoneDialog(
            defaultVillage = userVillage,
            errorMessage   = dialogError,
            onDismiss      = { showAddDialog = false; dialogError = "" },
            onConfirm      = { name, village ->
                onAddZone(name, village) { err -> dialogError = err }
                if (dialogError.isEmpty()) showAddDialog = false
            }
        )
    }
}

@Composable
fun ZoneCard(zone: ZoneStatus, onClick: () -> Unit) {
    Card(
        modifier  = Modifier.fillMaxWidth().clickable { onClick() },
        shape     = RoundedCornerShape(18.dp),
        colors    = CardDefaults.cardColors(containerColor = Color.White),
        border    = BorderStroke(1.dp, if (zone.isPowerOn) Color(0xFFA5D6A7) else Color(0xFFEF9A9A)),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(50.dp)
                    .background(
                        if (zone.isPowerOn) Color(0xFFE8F5E9) else Color(0xFFFFEBEE),
                        CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(if (zone.isPowerOn) "⚡" else "🔴", fontSize = 22.sp)
            }

            Spacer(Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(zone.zoneName, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, color = Color.Black)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(12.dp))
                    Text(" ${zone.village}", color = Color.Gray, fontSize = 12.sp)
                }
                Text(zone.lastUpdated, color = Color.Gray, fontSize = 11.sp)
                Text(
                    "by ${zone.updatedBy.substringBefore("@").ifBlank { "Community update" }}",
                    color = Color.Gray, fontSize = 11.sp
                )
            }

            Surface(
                color = if (zone.isPowerOn) Color(0xFFE8F5E9) else Color(0xFFFFEBEE),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, if (zone.isPowerOn) PrimaryGreen else ErrorRed)
            ) {
                Text(
                    text       = if (zone.isPowerOn) "ON" else "OFF",
                    modifier   = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    fontWeight = FontWeight.ExtraBold,
                    color      = if (zone.isPowerOn) PrimaryGreen else ErrorRed,
                    fontSize   = 14.sp
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddZoneDialog(
    defaultVillage: String,
    errorMessage: String,
    onDismiss: () -> Unit,
    onConfirm: (String, String) -> Unit
) {
    var zoneName by remember { mutableStateOf("") }
    var village  by remember { mutableStateOf(defaultVillage) }

    Dialog(onDismissRequest = onDismiss) {
        Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(modifier = Modifier.padding(24.dp)) {
                Text("➕  Add Zone", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                Text("Add a transformer or feeder zone", color = Color.Gray, fontSize = 13.sp)
                Spacer(Modifier.height(20.dp))

                // ✅ Error message
                if (errorMessage.isNotBlank()) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors   = CardDefaults.cardColors(containerColor = Color(0xFFFFDAD6)),
                        shape    = RoundedCornerShape(10.dp)
                    ) {
                        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = ErrorRed, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(errorMessage, color = ErrorRed, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }

                OutlinedTextField(
                    value         = zoneName,
                    onValueChange = { zoneName = it },
                    label         = { Text("Zone / Transformer Name") },
                    placeholder   = { Text("e.g. Transformer RN-A1") },
                    modifier      = Modifier.fillMaxWidth(),
                    shape         = RoundedCornerShape(14.dp),
                    isError       = errorMessage.contains("Zone name", ignoreCase = true),
                    colors        = OutlinedTextFieldDefaults.colors(focusedBorderColor = PrimaryGreen, focusedLabelColor = PrimaryGreen)
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value         = village,
                    onValueChange = { village = it },
                    label         = { Text("Village Name") },
                    modifier      = Modifier.fillMaxWidth(),
                    shape         = RoundedCornerShape(14.dp),
                    isError       = errorMessage.contains("Village", ignoreCase = true),
                    colors        = OutlinedTextFieldDefaults.colors(focusedBorderColor = PrimaryGreen, focusedLabelColor = PrimaryGreen)
                )
                Spacer(Modifier.height(20.dp))
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) {
                        Text("Cancel")
                    }
                    Button(
                        onClick  = { onConfirm(zoneName, village) },
                        modifier = Modifier.weight(1f),
                        shape    = RoundedCornerShape(14.dp),
                        colors   = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                    ) { Text("Add Zone", fontWeight = FontWeight.Bold) }
                }
            }
        }
    }
}

// ── PUMP TIMER ────────────────────────────────────────────────────
@Composable
fun PumpTimerScreen() {
    var selectedCropId by remember { mutableStateOf(AllCrops[0].id) }
    var acres          by remember { mutableStateOf(5f) }
    val crop           = AllCrops.find { it.id == selectedCropId } ?: AllCrops[0]
    val recommendation = (acres * crop.multiplier).toInt()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("🌾  Pump Optimizer", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.ExtraBold)
        Text("Calculate irrigation run time for your crop", color = Color.Gray, fontSize = 13.sp)
        Spacer(Modifier.height(20.dp))

        Text("Select Crop  (${AllCrops.size} types)", fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Spacer(Modifier.height(8.dp))

        Row(modifier = Modifier.horizontalScroll(rememberScrollState())) {
            AllCrops.forEach { c ->
                val sel = selectedCropId == c.id
                Card(
                    modifier = Modifier.width(128.dp).padding(end = 10.dp).clickable { selectedCropId = c.id },
                    colors   = CardDefaults.cardColors(containerColor = if (sel) PrimaryContainer else Color.White),
                    border   = BorderStroke(if (sel) 2.dp else 1.dp, if (sel) PrimaryGreen else SurfaceVariant),
                    shape    = RoundedCornerShape(16.dp)
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Text(c.name, fontWeight = if (sel) FontWeight.ExtraBold else FontWeight.Normal, fontSize = 13.sp)
                        Text("${c.waterNeeds} water", style = MaterialTheme.typography.labelSmall, color = Color.Gray)
                    }
                }
            }
        }

        Spacer(Modifier.height(20.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Land Size", fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text("${acres.toInt()} Acres", fontWeight = FontWeight.ExtraBold, color = PrimaryGreen, fontSize = 18.sp)
        }
        Slider(
            value         = acres,
            onValueChange = { acres = it },
            valueRange    = 1f..50f,
            colors        = SliderDefaults.colors(thumbColor = PrimaryGreen, activeTrackColor = PrimaryGreen)
        )
        Spacer(Modifier.height(20.dp))

        Card(
            modifier  = Modifier.fillMaxWidth(),
            colors    = CardDefaults.cardColors(containerColor = PrimaryGreen),
            shape     = RoundedCornerShape(24.dp),
            elevation = CardDefaults.cardElevation(6.dp)
        ) {
            Column(modifier = Modifier.padding(32.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("RECOMMENDED PUMP TIME", color = OnPrimary.copy(alpha = 0.8f), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("$recommendation", style = MaterialTheme.typography.displayLarge, color = OnPrimary, fontWeight = FontWeight.Black)
                Text("HOURS", color = OnPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                Spacer(Modifier.height(6.dp))
                Text("for ${acres.toInt()} acres · ${crop.name}", color = OnPrimary.copy(alpha = 0.75f), fontSize = 13.sp)
            }
        }
    }
}

// ── ALERTS SCREEN ─────────────────────────────────────────────────
@Composable
fun AlertsScreen(viewModel: PowerViewModel) {
    val alerts      by viewModel.alerts.collectAsState()
    val userVillage by viewModel.userVillage.collectAsState()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("🔔  Community Alerts", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.ExtraBold)

        if (userVillage.isNotBlank()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Place, contentDescription = null, tint = PrimaryGreen, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(4.dp))
                Text(
                    "Alerts from $userVillage only",
                    color      = PrimaryGreen,
                    fontWeight = FontWeight.Bold,
                    fontSize   = 13.sp
                )
            }
        }

        Spacer(Modifier.height(16.dp))

        if (alerts.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🔔", fontSize = 56.sp)
                    Spacer(Modifier.height(12.dp))
                    Text("No alerts yet", color = Color.Gray, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "When a farmer marks power ON or OFF\nin $userVillage, it will appear here.",
                        color     = Color.Gray,
                        fontSize  = 13.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(alerts, key = { it.alertId }) { alert ->
                    val isInfo = alert.type == "INFO"
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape    = RoundedCornerShape(16.dp),
                        colors   = CardDefaults.cardColors(
                            containerColor = if (isInfo) Color(0xFFE8F5E9) else Color(0xFFFFEBEE)
                        ),
                        border = BorderStroke(1.dp, if (isInfo) Color(0xFF81C784) else Color(0xFFEF9A9A))
                    ) {
                        Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .background(if (isInfo) PrimaryGreen else ErrorRed, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(if (isInfo) "⚡" else "🔴", fontSize = 20.sp)
                            }
                            Spacer(Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(alert.message, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.Black)
                                Spacer(Modifier.height(4.dp))
                                Text(alert.timeAgo, color = Color.Gray, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

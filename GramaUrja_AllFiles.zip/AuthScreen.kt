package com.example.gramaurja

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreen(viewModel: AuthViewModel, onAuthSuccess: () -> Unit) {
    var isLoginMode by remember { mutableStateOf(true) }
    var name     by remember { mutableStateOf("") }
    var email    by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var village  by remember { mutableStateOf("") }
    var showPass by remember { mutableStateOf(false) }
    val authState by viewModel.authState.collectAsState()

    LaunchedEffect(authState) {
        if (authState is AuthState.Success) { onAuthSuccess(); viewModel.resetState() }
    }

    Box(modifier = Modifier.fillMaxSize().background(AppSurface)) {
        Column(
            modifier            = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(52.dp))
            Box(
                modifier         = Modifier.size(90.dp).background(PrimaryGreen, RoundedCornerShape(28.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.ElectricBolt, contentDescription = null, tint = Color.White, modifier = Modifier.size(48.dp))
            }
            Spacer(Modifier.height(14.dp))
            Text("Grama-Urja", fontSize = 32.sp, fontWeight = FontWeight.ExtraBold, color = PrimaryGreen)
            Text("Community Power Monitor", color = Color.Gray, fontSize = 14.sp)
            Spacer(Modifier.height(36.dp))

            Card(
                modifier  = Modifier.fillMaxWidth(),
                shape     = RoundedCornerShape(24.dp),
                colors    = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(3.dp)
            ) {
                Column(modifier = Modifier.padding(24.dp)) {
                    Text(if (isLoginMode) "Welcome Back!" else "Create Account", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                    Text(
                        if (isLoginMode) "Sign in to check power status in your village"
                        else "Join your village power monitoring network",
                        color = Color.Gray, fontSize = 13.sp
                    )
                    Spacer(Modifier.height(22.dp))

                    AnimatedVisibility(visible = !isLoginMode) {
                        Column {
                            AuthTextField(name,    { name = it },    "Full Name",                 Icons.Default.Person)
                            Spacer(Modifier.height(12.dp))
                            AuthTextField(village, { village = it }, "Your Village (e.g. Mandya)", Icons.Default.LocationOn)
                            Spacer(Modifier.height(12.dp))
                        }
                    }

                    AuthTextField(email, { email = it }, "Email Address", Icons.Default.Email)
                    Spacer(Modifier.height(12.dp))

                    OutlinedTextField(
                        value                = password,
                        onValueChange        = { password = it },
                        modifier             = Modifier.fillMaxWidth(),
                        label                = { Text("Password") },
                        leadingIcon          = { Icon(Icons.Default.Lock, contentDescription = null) },
                        trailingIcon         = {
                            IconButton(onClick = { showPass = !showPass }) {
                                Icon(if (showPass) Icons.Default.VisibilityOff else Icons.Default.Visibility, contentDescription = null)
                            }
                        },
                        visualTransformation = if (showPass) VisualTransformation.None else PasswordVisualTransformation(),
                        shape                = RoundedCornerShape(14.dp),
                        colors               = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PrimaryGreen, focusedLabelColor = PrimaryGreen
                        )
                    )
                    Spacer(Modifier.height(22.dp))

                    if (authState is AuthState.Error) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors   = CardDefaults.cardColors(containerColor = Color(0xFFFFDAD6)),
                            shape    = RoundedCornerShape(12.dp)
                        ) {
                            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = ErrorRed, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text((authState as AuthState.Error).message, color = ErrorRed, fontSize = 13.sp)
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                    }

                    Button(
                        onClick  = {
                            if (isLoginMode) viewModel.login(email, password)
                            else viewModel.register(name, email, password, village)
                        },
                        modifier = Modifier.fillMaxWidth().height(56.dp),
                        shape    = RoundedCornerShape(16.dp),
                        colors   = ButtonDefaults.buttonColors(containerColor = PrimaryGreen),
                        enabled  = authState !is AuthState.Loading
                    ) {
                        if (authState is AuthState.Loading)
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp), strokeWidth = 2.dp)
                        else
                            Text(if (isLoginMode) "Sign In" else "Create Account", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(Modifier.height(20.dp))
            Row(horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                Text(if (isLoginMode) "Don't have an account? " else "Already have an account? ", color = Color.Gray)
                Text(
                    if (isLoginMode) "Register" else "Sign In",
                    color    = PrimaryGreen, fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.clickable { isLoginMode = !isLoginMode; viewModel.resetState() }
                )
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthTextField(
    value: String, onValueChange: (String) -> Unit,
    label: String, icon: androidx.compose.ui.graphics.vector.ImageVector
) {
    OutlinedTextField(
        value         = value, onValueChange = onValueChange,
        modifier      = Modifier.fillMaxWidth(),
        label         = { Text(label) },
        leadingIcon   = { Icon(icon, contentDescription = null) },
        shape         = RoundedCornerShape(14.dp),
        colors        = OutlinedTextFieldDefaults.colors(focusedBorderColor = PrimaryGreen, focusedLabelColor = PrimaryGreen)
    )
}

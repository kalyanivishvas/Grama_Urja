package com.example.gramaurja

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

data class ZoneStatus(
    val zoneId: String      = "",
    val zoneName: String    = "",
    val village: String     = "",
    val isPowerOn: Boolean  = false,
    val lastUpdated: String = "",
    val updatedBy: String   = "",
    val timestamp: Long     = 0L
)

data class AlertItem(
    val alertId: String = "",
    val message: String = "",
    val village: String = "",
    val timestamp: Long = 0L,
    val type: String    = "INFO",
    val timeAgo: String = ""
)

class PowerViewModel : ViewModel() {

    private val db   = FirebaseDatabase.getInstance().reference
    private val auth = FirebaseAuth.getInstance()

    // ── Public state flows ────────────────────────────────────────
    private val _zones        = MutableStateFlow<List<ZoneStatus>>(emptyList())
    val zones: StateFlow<List<ZoneStatus>> = _zones

    private val _selectedZone = MutableStateFlow<ZoneStatus?>(null)
    val selectedZone: StateFlow<ZoneStatus?> = _selectedZone

    private val _alerts       = MutableStateFlow<List<AlertItem>>(emptyList())
    val alerts: StateFlow<List<AlertItem>> = _alerts

    private val _isLoading    = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading

    private val _isOnline     = MutableStateFlow(true)
    val isOnline: StateFlow<Boolean> = _isOnline

    private val _isSynced     = MutableStateFlow(false)
    val isSynced: StateFlow<Boolean> = _isSynced

    private val _userVillage  = MutableStateFlow("")
    val userVillage: StateFlow<String> = _userVillage

    // One-shot events for Snackbar
    private val _snackbarMsg  = MutableSharedFlow<String>()
    val snackbarMsg: SharedFlow<String> = _snackbarMsg

    private var zonesListener:  ValueEventListener? = null
    private var alertsListener: ValueEventListener? = null
    private var tickerJob: Job? = null

    // ── INIT ─────────────────────────────────────────────────────
    fun startListening() {
        try { FirebaseDatabase.getInstance().setPersistenceEnabled(true) } catch (_: Exception) {}
        viewModelScope.launch {
            loadUserVillage()
            if (_userVillage.value.isNotBlank()) {
                subscribeToFcmTopic(_userVillage.value)
                seedZonesIfEmpty(_userVillage.value)
                listenToZones(_userVillage.value)
                listenToAlerts(_userVillage.value)
                startTicker()
            }
        }
    }

    // ── LOAD USER VILLAGE FROM FIREBASE ──────────────────────────
    private suspend fun loadUserVillage() {
        val uid = auth.currentUser?.uid ?: return
        try {
            val snap = db.child("users").child(uid).get().await()
            val v = snap.child("village").getValue(String::class.java) ?: ""
            _userVillage.value = v
        } catch (_: Exception) {}
    }

    // ── FCM TOPIC SUBSCRIPTION ───────────────────────────────────
    private fun subscribeToFcmTopic(village: String) {
        val safeTopic = "village_${village.trim().replace(Regex("[^a-zA-Z0-9]"), "_")}"
        FirebaseMessaging.getInstance().subscribeToTopic(safeTopic)
    }

    // ── LISTEN TO ZONES (filtered by village) ────────────────────
    private fun listenToZones(village: String) {
        zonesListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                _isOnline.value  = true
                _isLoading.value = false
                _isSynced.value  = true

                val list = mutableListOf<ZoneStatus>()
                for (child in snapshot.children) {
                    val zoneVillage = child.child("village").getValue(String::class.java)
                                   ?: child.child("location").getValue(String::class.java)
                                   ?: ""
                    // ✅ STRICT village filter — only show user's village
                    if (!zoneVillage.equals(village, ignoreCase = true)) continue

                    val name = child.child("zoneName").getValue(String::class.java)
                            ?: child.child("name").getValue(String::class.java)
                            ?: "Unknown Zone"
                    val status    = child.child("isPowerOn").getValue(Boolean::class.java)
                                 ?: child.child("status").getValue(Boolean::class.java)
                                 ?: false
                    val updatedBy = child.child("updatedBy").getValue(String::class.java) ?: "Community update"
                    val ts        = child.child("timestamp").getValue(Long::class.java) ?: 0L

                    list.add(ZoneStatus(
                        zoneId      = child.key ?: "",
                        zoneName    = name,
                        village     = zoneVillage,
                        isPowerOn   = status,
                        updatedBy   = updatedBy,
                        timestamp   = ts,
                        lastUpdated = timeAgo(ts)
                    ))
                }
                _zones.value = list
                val cur = _selectedZone.value
                _selectedZone.value = if (cur != null)
                    list.find { it.zoneId == cur.zoneId } ?: list.firstOrNull()
                else
                    list.firstOrNull()
            }
            override fun onCancelled(error: DatabaseError) {
                _isOnline.value  = false
                _isLoading.value = false
                _isSynced.value  = false
            }
        }
        db.child("zones").addValueEventListener(zonesListener!!)
    }

    // ── LISTEN TO ALERTS (filtered by village) ───────────────────
    private fun listenToAlerts(village: String) {
        alertsListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = mutableListOf<AlertItem>()
                for (child in snapshot.children) {
                    val alertVillage = child.child("village").getValue(String::class.java) ?: ""
                    // ✅ Only show alerts for user's village
                    if (!alertVillage.equals(village, ignoreCase = true)) continue

                    val ts = child.child("timestamp").getValue(Long::class.java) ?: 0L
                    list.add(AlertItem(
                        alertId   = child.key ?: "",
                        message   = child.child("message").getValue(String::class.java) ?: "",
                        village   = alertVillage,
                        timestamp = ts,
                        type      = child.child("type").getValue(String::class.java) ?: "INFO",
                        timeAgo   = timeAgo(ts)
                    ))
                }
                _alerts.value = list.sortedByDescending { it.timestamp }
            }
            override fun onCancelled(error: DatabaseError) {}
        }
        db.child("alerts").addValueEventListener(alertsListener!!)
    }

    // ── TICKER — refresh "X mins ago" every 30s ──────────────────
    private fun startTicker() {
        tickerJob = viewModelScope.launch {
            while (isActive) {
                delay(30_000)
                _zones.value  = _zones.value.map  { it.copy(lastUpdated = timeAgo(it.timestamp)) }
                _alerts.value = _alerts.value.map { it.copy(timeAgo = timeAgo(it.timestamp)) }
            }
        }
    }

    fun selectZone(zone: ZoneStatus) { _selectedZone.value = zone }

    // ── UPDATE POWER STATUS ──────────────────────────────────────
    fun updatePowerStatus(zoneId: String, isPowerOn: Boolean) {
        val zone  = _zones.value.find { it.zoneId == zoneId } ?: return
        val email = auth.currentUser?.email ?: "Community update"

        // ✅ SPAM PROTECTION — 30 second cooldown
        val elapsed = System.currentTimeMillis() - zone.timestamp
        if (zone.isPowerOn == isPowerOn && elapsed < 30_000) {
            viewModelScope.launch {
                _snackbarMsg.emit("Please wait before updating again")
            }
            return
        }
        // Same status but enough time passed — allow
        if (zone.isPowerOn == isPowerOn && elapsed >= 30_000) {
            viewModelScope.launch { _snackbarMsg.emit("Status is already ${if (isPowerOn) "ON" else "OFF"}") }
            return
        }

        // Write update to Firebase
        db.child("zones").child(zoneId).updateChildren(mapOf(
            "isPowerOn"   to isPowerOn,
            "status"      to isPowerOn,
            "updatedBy"   to email,
            "village"     to zone.village,
            "location"    to zone.village,
            "timestamp"   to ServerValue.TIMESTAMP
        ))

        // ✅ Auto-create alert with village tag
        val msg = if (isPowerOn)
            "⚡ Power is back ON in ${zone.zoneName}, ${zone.village}"
        else
            "🔴 Power turned OFF in ${zone.zoneName}, ${zone.village}"

        db.child("alerts").push().setValue(mapOf(
            "zoneId"    to zoneId,
            "village"   to zone.village,
            "message"   to msg,
            "timestamp" to ServerValue.TIMESTAMP,
            "type"      to if (isPowerOn) "INFO" else "WARNING"
        ))

        // ✅ Snackbar confirmation
        viewModelScope.launch {
            _snackbarMsg.emit("Status updated successfully ✓")
        }
    }

    // ── ADD ZONE WITH DUPLICATE CHECK ────────────────────────────
    fun addZone(zoneName: String, village: String, onError: (String) -> Unit) {
        if (zoneName.isBlank()) { onError("Zone name cannot be empty"); return }
        if (village.isBlank())  { onError("Village name cannot be empty"); return }

        // Check for duplicate
        val duplicate = _zones.value.any {
            it.zoneName.equals(zoneName.trim(), ignoreCase = true) &&
            it.village.equals(village.trim(), ignoreCase = true)
        }
        if (duplicate) { onError("Zone already exists in $village"); return }

        val email = auth.currentUser?.email ?: "system"
        db.child("zones").push().setValue(mapOf(
            "zoneName"  to zoneName.trim(),
            "name"      to zoneName.trim(),
            "village"   to village.trim(),
            "location"  to village.trim(),
            "isPowerOn" to false,
            "status"    to false,
            "updatedBy" to email,
            "timestamp" to ServerValue.TIMESTAMP
        ))
        viewModelScope.launch { _snackbarMsg.emit("Zone added successfully ✓") }
    }

    // ── SEED DATA per village ─────────────────────────────────────
    private fun seedZonesIfEmpty(village: String) {
        db.child("zones").get().addOnSuccessListener { snap ->
            val hasVillageZone = snap.children.any {
                (it.child("village").getValue(String::class.java) ?: "")
                    .equals(village, ignoreCase = true)
            }
            if (!hasVillageZone) {
                // Seed 3 zones for whatever village the user registered in
                listOf(
                    mapOf("zoneName" to "Transformer ${village.take(3).uppercase()}-A1", "name" to "Transformer ${village.take(3).uppercase()}-A1",
                          "village" to village, "location" to village,
                          "isPowerOn" to true,  "status" to true,  "updatedBy" to "system", "timestamp" to ServerValue.TIMESTAMP),
                    mapOf("zoneName" to "Feeder ${village.take(3).uppercase()}-B2",      "name" to "Feeder ${village.take(3).uppercase()}-B2",
                          "village" to village, "location" to village,
                          "isPowerOn" to false, "status" to false, "updatedBy" to "system", "timestamp" to ServerValue.TIMESTAMP),
                    mapOf("zoneName" to "Canal Zone ${village.take(3).uppercase()}-C3",  "name" to "Canal Zone ${village.take(3).uppercase()}-C3",
                          "village" to village, "location" to village,
                          "isPowerOn" to true,  "status" to true,  "updatedBy" to "system", "timestamp" to ServerValue.TIMESTAMP)
                ).forEach { db.child("zones").push().setValue(it) }
            }
        }
    }

    fun stopListening() {
        zonesListener?.let  { db.child("zones").removeEventListener(it) }
        alertsListener?.let { db.child("alerts").removeEventListener(it) }
        tickerJob?.cancel()
    }

    override fun onCleared() { super.onCleared(); stopListening() }

    fun timeAgo(ts: Long): String {
        if (ts == 0L) return "Just now"
        val diff  = System.currentTimeMillis() - ts
        val mins  = diff / 60_000
        val hours = diff / 3_600_000
        val days  = diff / 86_400_000
        return when {
            mins  < 1  -> "Just now"
            mins  < 60 -> "$mins min${if (mins > 1) "s" else ""} ago"
            hours < 24 -> "$hours hr${if (hours > 1) "s" else ""} ago"
            else       -> "$days day${if (days > 1) "s" else ""} ago"
        }
    }
}

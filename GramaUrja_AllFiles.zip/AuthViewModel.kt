package com.example.gramaurja

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

sealed class AuthState {
    object Idle    : AuthState()
    object Loading : AuthState()
    object Success : AuthState()
    data class Error(val message: String) : AuthState()
}

class AuthViewModel : ViewModel() {
    private val auth = FirebaseAuth.getInstance()
    private val db   = FirebaseDatabase.getInstance().reference

    private val _authState = MutableStateFlow<AuthState>(AuthState.Idle)
    val authState: StateFlow<AuthState> = _authState

    fun isLoggedIn() = auth.currentUser != null

    fun register(name: String, email: String, password: String, village: String) {
        if (name.isBlank() || email.isBlank() || password.isBlank() || village.isBlank()) {
            _authState.value = AuthState.Error("Please fill in all fields"); return
        }
        if (password.length < 6) {
            _authState.value = AuthState.Error("Password must be at least 6 characters"); return
        }
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            try {
                val result = auth.createUserWithEmailAndPassword(email, password).await()
                val uid    = result.user?.uid ?: throw Exception("No user ID")
                // ✅ Save village so PowerViewModel can load it for filtering
                db.child("users").child(uid).setValue(mapOf(
                    "name"    to name.trim(),
                    "email"   to email.trim(),
                    "village" to village.trim(),
                    "uid"     to uid
                )).await()
                _authState.value = AuthState.Success
            } catch (e: Exception) {
                _authState.value = AuthState.Error(e.message ?: "Registration failed")
            }
        }
    }

    fun login(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            _authState.value = AuthState.Error("Please enter email and password"); return
        }
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            try {
                auth.signInWithEmailAndPassword(email, password).await()
                _authState.value = AuthState.Success
            } catch (e: Exception) {
                _authState.value = AuthState.Error(e.message ?: "Login failed. Check email and password.")
            }
        }
    }

    fun logout()     { auth.signOut(); _authState.value = AuthState.Idle }
    fun resetState() { _authState.value = AuthState.Idle }
}

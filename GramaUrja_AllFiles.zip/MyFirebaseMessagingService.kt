package com.example.gramaurja

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class MyFirebaseMessagingService : FirebaseMessagingService() {

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        // Works in background AND when app is closed
        val title = remoteMessage.notification?.title
                 ?: remoteMessage.data["title"]
                 ?: "⚡ Grama-Urja Alert"
        val body  = remoteMessage.notification?.body
                 ?: remoteMessage.data["body"]
                 ?: "Power status changed in your village!"
        showNotification(title, body)
    }

    override fun onNewToken(token: String) {
        // Optionally save FCM token to Firebase for server-side push
    }

    private fun showNotification(title: String, body: String) {
        val channelId = "grama_urja_power_alerts"
        val manager   = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(
                    channelId,
                    "Power Status Alerts",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description          = "Notifies when power turns ON or OFF in your zone"
                    enableLights(true)
                    enableVibration(true)
                }
            )
        }

        val intent  = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        val pending = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pending)
            .build()

        manager.notify(System.currentTimeMillis().toInt(), notification)
    }
}
